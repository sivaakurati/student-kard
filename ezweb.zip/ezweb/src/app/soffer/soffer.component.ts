import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-soffer',
  templateUrl: './soffer.component.html',
  styleUrls: ['./soffer.component.css']
})
export class SofferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
