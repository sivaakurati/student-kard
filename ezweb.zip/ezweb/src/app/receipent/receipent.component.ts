import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-receipent',
  templateUrl: './receipent.component.html',
  styleUrls: ['./receipent.component.css']
})
export class ReceipentComponent implements OnInit {

  receipents: any;

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  delete(receipent: any): void {
  }

  edit(receipent: any): void {
  }

  add(receipent: any): void {
  }
}
